# OperaGX Sonic Frontiers Mod

![SonicImage](https://github.com/CesarEduL/OperaGX-Sonic-Frontiers-Mod/blob/main/images/Sonic.png "Sonic Frontiers chill")

Mod de Opera GX con fondos y OST de la franquicia Sonic the Hedgehog. Contiene una vibra y música acogedora al mismo tiempo que disfrutas tu tiempo navegando por el internet, este es un proyecto de pruebas hecho por un fan para fans, espero les guste.


## Instalación

Primero, clona o descarga el repositorio. Luego use la opción "cargar descomprimido" en opera://extensiones después de habilitar el **modo de desarrollador**. Quizá a la fecha también se encuentre subido en la página de Opera Mods.


## Que hace este mod?

- Agrega dos wallpapers tanto para el modo light y dark de opera
- Agrega música de fondo para disfrutar mientras navegas


## Créditos

Utilicé el OST que encontré en los canales de 
- [RetrOfir's Music](https://www.youtube.com/watch?v=3LBW2Wwjiz8 "Theme of Starfall Islands LoFi Hip Hop Remix").
- [Dream Kittu](https://www.youtube.com/watch?v=zEqyIKMyNcw "FADED HILLS Lofi Music Box Remix").
- [Sonic the Hedgehog✔️](https://www.youtube.com/watch?v=7NZMTMPZULU "Big the Cat Lo-Fi").

## Créditos

Paleta de colores:
- #CC0000
- #2628C0
- #1C1A37
- #F9F2C8